import React from "react";
import "./NewLoading.css";

const NewLoading = () => {
  return (
    <div className="container">
      <span>데이터 로드중...</span>
    </div>
  );
};

export default NewLoading;
