import React, { useEffect } from "react";
import { useState } from "react";
import { useHistory } from "react-router";
import "./UserPage.css";

const UserPage = ({ match, userObj }) => {
  const [userIdRef, setUserIdRef] = useState("");
  const history = useHistory();
  useEffect(() => {
    console.log(userObj);
    if (match.params) {
      if (match.params === undefined) {
        history.push("/profile");
      }
      setUserIdRef(match.params);
    }
  });
  return (
    <div className="user_page">
      <span>여기는 유저페이지</span>
    </div>
  );
};
export default UserPage;
