import React from "react";

const GetUserLikeNweets = () => {
  return <div>유저의 좋아요 트윗</div>;
};

export default GetUserLikeNweets;
